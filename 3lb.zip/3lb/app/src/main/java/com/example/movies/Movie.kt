package com.example.movies

data class Movie(
    val title: String,
    val description: String,
    val imageUrl: String
)