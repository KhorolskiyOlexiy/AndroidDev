package com.example.lb1

data class Animal (val name : String, val description: String, val imageResId: String){
}